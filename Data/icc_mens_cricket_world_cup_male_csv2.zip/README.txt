All Men's ICC Men's Cricket World Cup match data in CSV format
==============================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Men's ICC Men's Cricket World Cup matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2023-10-11 - international - ODI - male - 1384400 - Afghanistan vs India
2023-10-10 - international - ODI - male - 1384398 - England vs Bangladesh
2023-10-10 - international - ODI - male - 1384399 - Sri Lanka vs Pakistan
2023-10-09 - international - ODI - male - 1384397 - New Zealand vs Netherlands
2023-10-08 - international - ODI - male - 1384396 - Australia vs India
2023-10-07 - international - ODI - male - 1384394 - Afghanistan vs Bangladesh
2023-10-07 - international - ODI - male - 1384395 - South Africa vs Sri Lanka
2023-10-06 - international - ODI - male - 1384393 - Pakistan vs Netherlands
2023-10-05 - international - ODI - male - 1384392 - England vs New Zealand
2019-07-14 - international - ODI - male - 1144530 - England vs New Zealand
2019-07-11 - international - ODI - male - 1144529 - Australia vs England
2019-07-09 - international - ODI - male - 1144528 - India vs New Zealand
2019-07-06 - international - ODI - male - 1144526 - India vs Sri Lanka
2019-07-06 - international - ODI - male - 1144527 - Australia vs South Africa
2019-07-05 - international - ODI - male - 1144525 - Bangladesh vs Pakistan
2019-07-04 - international - ODI - male - 1144524 - Afghanistan vs West Indies
2019-07-03 - international - ODI - male - 1144523 - England vs New Zealand
2019-07-02 - international - ODI - male - 1144522 - Bangladesh vs India
2019-07-01 - international - ODI - male - 1144521 - Sri Lanka vs West Indies
2019-06-30 - international - ODI - male - 1144520 - England vs India
2019-06-29 - international - ODI - male - 1144518 - Afghanistan vs Pakistan
2019-06-29 - international - ODI - male - 1144519 - Australia vs New Zealand
2019-06-28 - international - ODI - male - 1144517 - South Africa vs Sri Lanka
2019-06-27 - international - ODI - male - 1144516 - India vs West Indies
2019-06-26 - international - ODI - male - 1144515 - New Zealand vs Pakistan
2019-06-25 - international - ODI - male - 1144514 - England vs Australia
2019-06-24 - international - ODI - male - 1144513 - Afghanistan vs Bangladesh
2019-06-23 - international - ODI - male - 1144512 - Pakistan vs South Africa
2019-06-22 - international - ODI - male - 1144510 - Afghanistan vs India
2019-06-22 - international - ODI - male - 1144511 - New Zealand vs West Indies
2019-06-21 - international - ODI - male - 1144509 - England vs Sri Lanka
2019-06-20 - international - ODI - male - 1144508 - Australia vs Bangladesh
2019-06-19 - international - ODI - male - 1144507 - New Zealand vs South Africa
2019-06-18 - international - ODI - male - 1144506 - England vs Afghanistan
2019-06-17 - international - ODI - male - 1144505 - Bangladesh vs West Indies
2019-06-16 - international - ODI - male - 1144504 - India vs Pakistan
2019-06-15 - international - ODI - male - 1144502 - Australia vs Sri Lanka
2019-06-15 - international - ODI - male - 1144503 - Afghanistan vs South Africa
2019-06-14 - international - ODI - male - 1144501 - England vs West Indies
2019-06-12 - international - ODI - male - 1144499 - Australia vs Pakistan
2019-06-10 - international - ODI - male - 1144497 - South Africa vs West Indies
2019-06-09 - international - ODI - male - 1144496 - Australia vs India
2019-06-08 - international - ODI - male - 1144494 - England vs Bangladesh
2019-06-08 - international - ODI - male - 1144495 - Afghanistan vs New Zealand
2019-06-06 - international - ODI - male - 1144492 - Australia vs West Indies
2019-06-05 - international - ODI - male - 1144490 - India vs South Africa
2019-06-05 - international - ODI - male - 1144491 - Bangladesh vs New Zealand
2019-06-04 - international - ODI - male - 1144489 - Afghanistan vs Sri Lanka
2019-06-03 - international - ODI - male - 1144488 - England vs Pakistan
2019-06-02 - international - ODI - male - 1144487 - Bangladesh vs South Africa
2019-06-01 - international - ODI - male - 1144485 - New Zealand vs Sri Lanka
2019-06-01 - international - ODI - male - 1144486 - Afghanistan vs Australia
2019-05-31 - international - ODI - male - 1144484 - Pakistan vs West Indies
2019-05-30 - international - ODI - male - 1144483 - England vs South Africa
2015-03-29 - international - ODI - male - 656495 - Australia vs New Zealand
2015-03-26 - international - ODI - male - 656493 - Australia vs India
2015-03-24 - international - ODI - male - 656491 - New Zealand vs South Africa
2015-03-21 - international - ODI - male - 656489 - New Zealand vs West Indies
2015-03-20 - international - ODI - male - 656487 - Australia vs Pakistan
2015-03-19 - international - ODI - male - 656485 - Bangladesh vs India
2015-03-18 - international - ODI - male - 656483 - South Africa vs Sri Lanka
2015-03-15 - international - ODI - male - 656479 - United Arab Emirates vs West Indies
2015-03-15 - international - ODI - male - 656481 - Ireland vs Pakistan
2015-03-14 - international - ODI - male - 656475 - India vs Zimbabwe
2015-03-14 - international - ODI - male - 656477 - Australia vs Scotland
2015-03-13 - international - ODI - male - 656471 - New Zealand vs Bangladesh
2015-03-13 - international - ODI - male - 656473 - Afghanistan vs England
2015-03-12 - international - ODI - male - 656469 - South Africa vs United Arab Emirates
2015-03-11 - international - ODI - male - 656467 - Scotland vs Sri Lanka
2015-03-10 - international - ODI - male - 656465 - India vs Ireland
2015-03-09 - international - ODI - male - 656463 - Bangladesh vs England
2015-03-08 - international - ODI - male - 656459 - New Zealand vs Afghanistan
2015-03-08 - international - ODI - male - 656461 - Australia vs Sri Lanka
2015-03-07 - international - ODI - male - 656455 - Pakistan vs South Africa
2015-03-07 - international - ODI - male - 656457 - Ireland vs Zimbabwe
2015-03-06 - international - ODI - male - 656453 - India vs West Indies
2015-03-05 - international - ODI - male - 656451 - Bangladesh vs Scotland
2015-03-04 - international - ODI - male - 656447 - Pakistan vs United Arab Emirates
2015-03-04 - international - ODI - male - 656449 - Australia vs Afghanistan
2015-03-03 - international - ODI - male - 656445 - Ireland vs South Africa
2015-03-01 - international - ODI - male - 656441 - England vs Sri Lanka
2015-03-01 - international - ODI - male - 656443 - Pakistan vs Zimbabwe
2015-02-28 - international - ODI - male - 656437 - New Zealand vs Australia
2015-02-28 - international - ODI - male - 656439 - India vs United Arab Emirates
2015-02-27 - international - ODI - male - 656435 - South Africa vs West Indies
2015-02-26 - international - ODI - male - 656431 - Afghanistan vs Scotland
2015-02-26 - international - ODI - male - 656433 - Bangladesh vs Sri Lanka
2015-02-25 - international - ODI - male - 656429 - Ireland vs United Arab Emirates
2015-02-24 - international - ODI - male - 656427 - West Indies vs Zimbabwe
2015-02-23 - international - ODI - male - 656425 - England vs Scotland
2015-02-22 - international - ODI - male - 656421 - Afghanistan vs Sri Lanka
2015-02-22 - international - ODI - male - 656423 - India vs South Africa
2015-02-21 - international - ODI - male - 656417 - Pakistan vs West Indies
2015-02-20 - international - ODI - male - 656415 - New Zealand vs England
2015-02-19 - international - ODI - male - 656413 - United Arab Emirates vs Zimbabwe
2015-02-18 - international - ODI - male - 656411 - Afghanistan vs Bangladesh
2015-02-17 - international - ODI - male - 656409 - New Zealand vs Scotland
2015-02-16 - international - ODI - male - 656407 - Ireland vs West Indies
2015-02-15 - international - ODI - male - 656403 - South Africa vs Zimbabwe
2015-02-15 - international - ODI - male - 656405 - India vs Pakistan
2015-02-14 - international - ODI - male - 656399 - New Zealand vs Sri Lanka
2015-02-14 - international - ODI - male - 656401 - Australia vs England
2011-04-02 - international - ODI - male - 433606 - India vs Sri Lanka
2011-03-30 - international - ODI - male - 433605 - India vs Pakistan
2011-03-29 - international - ODI - male - 433604 - Sri Lanka vs New Zealand
2011-03-26 - international - ODI - male - 433603 - Sri Lanka vs England
2011-03-25 - international - ODI - male - 433602 - New Zealand vs South Africa
2011-03-24 - international - ODI - male - 433601 - India vs Australia
2011-03-23 - international - ODI - male - 433600 - Pakistan vs West Indies
2011-03-20 - international - ODI - male - 433598 - Kenya vs Zimbabwe
2011-03-20 - international - ODI - male - 433599 - India vs West Indies
2011-03-19 - international - ODI - male - 433596 - Australia vs Pakistan
2011-03-19 - international - ODI - male - 433597 - Bangladesh vs South Africa
2011-03-18 - international - ODI - male - 433594 - New Zealand vs Sri Lanka
2011-03-18 - international - ODI - male - 433595 - Ireland vs Netherlands
2011-03-17 - international - ODI - male - 433593 - England vs West Indies
2011-03-16 - international - ODI - male - 433592 - Australia vs Canada
2011-03-15 - international - ODI - male - 433591 - Ireland vs South Africa
2011-03-14 - international - ODI - male - 433589 - Pakistan vs Zimbabwe
2011-03-14 - international - ODI - male - 433590 - Bangladesh vs Netherlands
2011-03-13 - international - ODI - male - 433587 - Canada vs New Zealand
2011-03-13 - international - ODI - male - 433588 - Australia vs Kenya
2011-03-12 - international - ODI - male - 433586 - India vs South Africa
2011-03-11 - international - ODI - male - 433584 - Ireland vs West Indies
2011-03-11 - international - ODI - male - 433585 - Bangladesh vs England
2011-03-10 - international - ODI - male - 433583 - Sri Lanka vs Zimbabwe
2011-03-09 - international - ODI - male - 433582 - India vs Netherlands
2011-03-08 - international - ODI - male - 433581 - New Zealand vs Pakistan
2011-03-07 - international - ODI - male - 433580 - Canada vs Kenya
2011-03-06 - international - ODI - male - 433578 - India vs Ireland
2011-03-06 - international - ODI - male - 433579 - England vs South Africa
2011-03-05 - international - ODI - male - 433577 - Sri Lanka vs Australia
2011-03-04 - international - ODI - male - 433575 - New Zealand vs Zimbabwe
2011-03-04 - international - ODI - male - 433576 - Bangladesh vs West Indies
2011-03-03 - international - ODI - male - 433573 - Netherlands vs South Africa
2011-03-03 - international - ODI - male - 433574 - Canada vs Pakistan
2011-03-02 - international - ODI - male - 433572 - England vs Ireland
2011-03-01 - international - ODI - male - 433571 - Sri Lanka vs Kenya
2011-02-28 - international - ODI - male - 433569 - Netherlands vs West Indies
2011-02-28 - international - ODI - male - 433570 - Canada vs Zimbabwe
2011-02-27 - international - ODI - male - 433568 - India vs England
2011-02-26 - international - ODI - male - 433567 - Sri Lanka vs Pakistan
2011-02-25 - international - ODI - male - 433565 - Australia vs New Zealand
2011-02-25 - international - ODI - male - 433566 - Bangladesh vs Ireland
2011-02-24 - international - ODI - male - 433564 - South Africa vs West Indies
2011-02-23 - international - ODI - male - 433563 - Kenya vs Pakistan
2011-02-22 - international - ODI - male - 433562 - England vs Netherlands
2011-02-21 - international - ODI - male - 433561 - Australia vs Zimbabwe
2011-02-20 - international - ODI - male - 433559 - Kenya vs New Zealand
2011-02-20 - international - ODI - male - 433560 - Sri Lanka vs Canada
2011-02-19 - international - ODI - male - 433558 - Bangladesh vs India
2007-04-28 - international - ODI - male - 247507 - Australia vs Sri Lanka
2007-04-25 - international - ODI - male - 247506 - Australia vs South Africa
2007-04-24 - international - ODI - male - 247505 - New Zealand vs Sri Lanka
2007-04-21 - international - ODI - male - 247504 - West Indies vs England
2007-04-20 - international - ODI - male - 247503 - Australia vs New Zealand
2007-04-19 - international - ODI - male - 247502 - West Indies vs Bangladesh
2007-04-18 - international - ODI - male - 247501 - Ireland vs Sri Lanka
2007-04-17 - international - ODI - male - 247500 - England vs South Africa
2007-04-16 - international - ODI - male - 247499 - Australia vs Sri Lanka
2007-04-15 - international - ODI - male - 247498 - Bangladesh vs Ireland
2007-04-14 - international - ODI - male - 247497 - New Zealand vs South Africa
2007-04-13 - international - ODI - male - 247496 - Australia vs Ireland
2007-04-12 - international - ODI - male - 247495 - New Zealand vs Sri Lanka
2007-04-11 - international - ODI - male - 247494 - Bangladesh vs England
2007-04-10 - international - ODI - male - 247493 - West Indies vs South Africa
2007-04-09 - international - ODI - male - 247492 - Ireland vs New Zealand
2007-04-08 - international - ODI - male - 247491 - Australia vs England
2007-04-07 - international - ODI - male - 247490 - Bangladesh vs South Africa
2007-04-04 - international - ODI - male - 247489 - England vs Sri Lanka
2007-04-03 - international - ODI - male - 247488 - Ireland vs South Africa
2007-04-02 - international - ODI - male - 247487 - Bangladesh vs New Zealand
2007-04-01 - international - ODI - male - 247486 - West Indies vs Sri Lanka
2007-03-31 - international - ODI - male - 247485 - Australia vs Bangladesh
2007-03-30 - international - ODI - male - 247484 - England vs Ireland
2007-03-29 - international - ODI - male - 247483 - West Indies vs New Zealand
2007-03-28 - international - ODI - male - 247482 - South Africa vs Sri Lanka
2007-03-27 - international - ODI - male - 247481 - West Indies vs Australia
2007-03-25 - international - ODI - male - 247480 - Bangladesh vs Bermuda
2007-03-24 - international - ODI - male - 247478 - Australia vs South Africa
2007-03-24 - international - ODI - male - 247479 - England vs Kenya
2007-03-23 - international - ODI - male - 247476 - India vs Sri Lanka
2007-03-23 - international - ODI - male - 247477 - West Indies vs Ireland
2007-03-22 - international - ODI - male - 247474 - Netherlands vs Scotland
2007-03-22 - international - ODI - male - 247475 - Canada vs New Zealand
2007-03-21 - international - ODI - male - 247472 - Bangladesh vs Sri Lanka
2007-03-21 - international - ODI - male - 247473 - Pakistan vs Zimbabwe
2007-03-20 - international - ODI - male - 247470 - Scotland vs South Africa
2007-03-20 - international - ODI - male - 247471 - Kenya vs New Zealand
2007-03-19 - international - ODI - male - 247468 - Bermuda vs India
2007-03-19 - international - ODI - male - 247469 - West Indies vs Zimbabwe
2007-03-18 - international - ODI - male - 247466 - Australia vs Netherlands
2007-03-18 - international - ODI - male - 247467 - Canada vs England
2007-03-17 - international - ODI - male - 247464 - Bangladesh vs India
2007-03-17 - international - ODI - male - 247465 - Ireland vs Pakistan
2007-03-16 - international - ODI - male - 247462 - Netherlands vs South Africa
2007-03-16 - international - ODI - male - 247463 - England vs New Zealand
2007-03-15 - international - ODI - male - 247460 - Bermuda vs Sri Lanka
2007-03-15 - international - ODI - male - 247461 - Ireland vs Zimbabwe
2007-03-14 - international - ODI - male - 247458 - Australia vs Scotland
2007-03-13 - international - ODI - male - 247457 - West Indies vs Pakistan
2003-03-23 - international - ODI - male - 65286 - Australia vs India
2003-03-20 - international - ODI - male - 65285 - India vs Kenya
2003-03-18 - international - ODI - male - 65284 - Australia vs Sri Lanka
2003-03-15 - international - ODI - male - 65282 - Sri Lanka vs Zimbabwe
2003-03-15 - international - ODI - male - 65283 - Kenya vs Australia
2003-03-14 - international - ODI - male - 65281 - New Zealand vs India
2003-03-12 - international - ODI - male - 65280 - Zimbabwe vs Kenya
2003-03-11 - international - ODI - male - 65279 - Australia vs New Zealand
2003-03-10 - international - ODI - male - 65278 - India vs Sri Lanka
2003-03-08 - international - ODI - male - 65277 - Zimbabwe vs New Zealand
2003-03-07 - international - ODI - male - 65275 - Australia vs Sri Lanka
2003-03-07 - international - ODI - male - 65276 - Kenya vs India
2003-03-04 - international - ODI - male - 65273 - Pakistan vs Zimbabwe
2003-03-03 - international - ODI - male - 65270 - Canada vs New Zealand
2003-03-03 - international - ODI - male - 65271 - Netherlands vs Namibia
2003-03-03 - international - ODI - male - 65272 - Sri Lanka vs South Africa
2003-03-02 - international - ODI - male - 65269 - England vs Australia
2003-03-01 - international - ODI - male - 65267 - Kenya vs Bangladesh
2003-03-01 - international - ODI - male - 65268 - Pakistan vs India
2003-02-28 - international - ODI - male - 65265 - Zimbabwe vs Netherlands
2003-02-28 - international - ODI - male - 65266 - Sri Lanka vs West Indies
2003-02-27 - international - ODI - male - 65263 - Australia vs Namibia
2003-02-27 - international - ODI - male - 65264 - South Africa vs Canada
2003-02-26 - international - ODI - male - 65261 - Bangladesh vs New Zealand
2003-02-26 - international - ODI - male - 65262 - India vs England
2003-02-25 - international - ODI - male - 65260 - Pakistan vs Netherlands
2003-02-24 - international - ODI - male - 65258 - Kenya vs Sri Lanka
2003-02-24 - international - ODI - male - 65259 - Zimbabwe vs Australia
2003-02-23 - international - ODI - male - 65256 - Canada vs West Indies
2003-02-23 - international - ODI - male - 65257 - India vs Namibia
2003-02-22 - international - ODI - male - 65254 - Bangladesh vs South Africa
2003-02-22 - international - ODI - male - 65255 - England vs Pakistan
2003-02-19 - international - ODI - male - 65250 - India vs Zimbabwe
2003-02-19 - international - ODI - male - 65251 - Canada vs Sri Lanka
2003-02-19 - international - ODI - male - 65252 - England vs Namibia
2003-02-18 - international - ODI - male - 65249 - West Indies vs Bangladesh
2003-02-16 - international - ODI - male - 65246 - Netherlands vs England
2003-02-16 - international - ODI - male - 65247 - Pakistan vs Namibia
2003-02-16 - international - ODI - male - 65248 - South Africa vs New Zealand
2003-02-15 - international - ODI - male - 65244 - India vs Australia
2003-02-15 - international - ODI - male - 65245 - Canada vs Kenya
2003-02-13 - international - ODI - male - 65242 - New Zealand vs West Indies
2003-02-12 - international - ODI - male - 65240 - Kenya vs South Africa
2003-02-12 - international - ODI - male - 65241 - India vs Netherlands
2003-02-11 - international - ODI - male - 65238 - Australia vs Pakistan
2003-02-11 - international - ODI - male - 65239 - Canada vs Bangladesh
2003-02-10 - international - ODI - male - 65236 - Zimbabwe vs Namibia
2003-02-10 - international - ODI - male - 65237 - Sri Lanka vs New Zealand
2003-02-09 - international - ODI - male - 65235 - West Indies vs South Africa

Consolidated data
-----------------

You may notice that there is an extra CSV file in this archive, called
"all_matches.csv". This file, as the name suggests, contains all of the
ball-by-ball data for matches from the archive in a single CSV. Hopefully
it will make use of the data easier in some cases.

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email  : stephen@cricsheet.org
  Twitter: @cricsheet
